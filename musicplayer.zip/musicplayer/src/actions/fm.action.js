// const data='new data';

export const FM__ADD = "FM__ADD";
export const MUSICBRAINZ__ADD = "MUSICBRAINZ__ADD";

export const addData = {
    type: ADD,
    payload: data
};

export default addData;

