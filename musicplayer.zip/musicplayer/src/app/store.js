import { createStore } from 'redux'
import FmReducer from '../reducers/fm.reducer'

const store = createStore(FmReducer, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__());


 export default store