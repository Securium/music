import React from 'react'
import { Link } from 'react-router-dom';
import './ReleaseTable';

const SearchTable = () => {
    return (
        <>
            <table class="table table-hover w-md-75">
                <thead className="dropdown">
                    <tr>
                        <th scope="col"><strong>Artist Name</strong></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody className="dropdown">
                    <tr>
                        <td >The Samuel Jackson Fian</td>
                        <td><Link to="/release">show release</Link></td>
                    </tr>

                </tbody>
            </table>
        </>
    )
}

export default SearchTable
