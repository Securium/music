import React from 'react'
import SearchTable from '../SearchTable'

const Results = () => {
    return (
        <section className="container my-3">
            <h4>Search Results:</h4>
            <hr/>
            <SearchTable />
        </section>
    )
}

export default Results
