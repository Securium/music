import React, { useState } from 'react'
import './serachform.css'



const SearchInput = ({title}) => {

    const [search, setSearch] = useState(null);

    const searchData = (e) => {
        setSearch(e.target.value)
    }
    const [responseData, setResponseData] = useState('')

    
    
    const fmSearch = async () => {
        const url = `http://ws.audioscrobbler.com//2.0/?method=album.search&album=${search}&api_key=2aa4d61b9f0bb9e66fa32d3d507cd19b&format=json`;
        
            // .then((resp) => resp.json())
            // .then((response) => setResponseData(response.data))
            // .then(data => setStoring(data.results))
            // .then(data => console.log(data.results))
            // // .then(() => dispatch({ type: 'ADD', payload: fmdata }))
            // .catch(err => console.log(err))

            // dispatch({ type: 'ADD', payload: store })
            // store.dispatch({
            //     type: 'ADD', payload: responseData
            // })
    }

    console.log(responseData)
    

    return (
        <div className="container my-4">
            <h1 >Search {title}</h1>
            <div className="searchform">
                <input class="form-control form-control-lg" type="text" placeholder="Search" name="search" onChange={searchData} />
                <button type="button" class="btn btn-primary searchBtn p-2" onClick={fmSearch} >
                    <i class="fa fa-search" aria-hidden="true"></i>
                </button>
            </div>
        </div>
    )
}

export default SearchInput
