import React from 'react'
import { Link } from 'react-router-dom'

const ReleaseTable = () => {
    return (
        <section className="search__res container my-3">
            <table class="table table-hover w-md-75">
                <thead className="dropdown">
                    <tr>
                        <th scope="col"><strong>Artist Name</strong></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody className="dropdown">
                    <tr>
                        <td >The Samuel Jackson Fian</td>
                        <td><Link to="/release">show release</Link></td>
                    </tr>
            
                </tbody>
            </table>
            <table class="table table-striped">
                    <thead>
                        <tr>
                        <th scope="col"></th>
                        <th scope="col">Year</th>
                        <th scope="col">Tile</th>
                        <th scope="col">Release Label</th>
                        <th scope="col">Number of Tracks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <th scope="row"><i class="fa fa-star" aria-hidden="true"></i></th>
                        <td>Artist Name</td>
                        <td>Lable</td>
                        <td>11</td>
                        <td>11</td>
                        </tr>
                        
                    </tbody>
            </table>
        </section>
    )
}

export default ReleaseTable
