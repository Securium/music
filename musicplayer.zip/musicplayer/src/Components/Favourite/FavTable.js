import React from 'react'

const FavTable = () => {
    return (
        <>
            <table class="table my-4 table-hover">
                <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col"><strong>Artist Name</strong></th>
                        <th scope="col">Last</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row"><i class="fa fa-star" aria-hidden="true"></i></th>
                        <td>The Jackson Five</td>
                        <td><a href="#showRelease">show release</a></td>
                    </tr>
        
                </tbody>
            </table>
        </>
    )
}

export default FavTable
