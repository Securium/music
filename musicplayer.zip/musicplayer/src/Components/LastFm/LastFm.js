import React from 'react'
import SearchInput from '../Search/SearchInput'
import LastFmSearch from './LastFmSearch'




const LastFm = ({title}) => {
    return (
        <>
            <section className="container my-4">
                <SearchInput title="LastFm" />
                {/* search result with image */}
                <p><strong>Results:</strong></p><hr/>
                <LastFmSearch />
            </section>
        </>
    )
}

export default LastFm
