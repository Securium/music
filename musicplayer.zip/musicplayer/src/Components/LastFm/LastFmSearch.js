import React from 'react'

const LastFmSearch = () => {
    return (
        <table class="table table-striped my-3 lastfm__table">
                <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col"><strong>Artist Name</strong></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">Image</th>
                        <td>Jackson 5</td>
                        <td className="text-right"><i class="fa fa-plus-circle fa-2x text-success" aria-hidden="true"></i></td> 
                    </tr>
            
                </tbody>
            </table>
    )
}

export default LastFmSearch
